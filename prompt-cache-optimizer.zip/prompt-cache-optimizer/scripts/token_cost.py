#!/usr/bin/env python3
"""Estimate the token cost of a file before reading it into context.

Usage:
    python token_cost.py <path>          # estimate one file
    python token_cost.py <path> <path>   # estimate several
    cat file | python token_cost.py -    # estimate stdin

Output is intentionally short (3-4 lines) to keep the check itself cheap.
Estimates are approximate: CJK ~0.9 token/char, latin word ~1.3 token, other ~0.5.
"""

import re
import sys

CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
WORD = re.compile(r"[A-Za-z0-9_]+")


def estimate_tokens(text: str) -> int:
    cjk = len(CJK.findall(text))
    words = WORD.findall(text)
    latin_chars = sum(len(w) for w in words)
    other = max(len(text) - cjk - latin_chars, 0)
    return int(cjk * 0.9 + len(words) * 1.3 + other * 0.5)


def advise(tokens: int) -> str:
    if tokens < 1500:
        return "直接读：体积可接受"
    if tokens < 6000:
        return "分段读：用 offset+limit 只读相关段落"
    if tokens < 25000:
        return "先 Grep 定位关键行，再读片段；不要整体读"
    return "交给子代理处理，只把结论带回主上下文"


def report(name: str, text: str) -> None:
    lines = text.count("\n") + 1 if text else 0
    tokens = estimate_tokens(text)
    print(f"{name}: {lines} 行 / {len(text)} 字符 / 约 {tokens} token -> {advise(tokens)}")


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__.strip())
        return 1
    if args[0] == "-":
        report("<stdin>", sys.stdin.read())
        return 0
    for path in args:
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                report(path, fh.read())
        except OSError as exc:
            print(f"{path}: 读取失败 {exc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
